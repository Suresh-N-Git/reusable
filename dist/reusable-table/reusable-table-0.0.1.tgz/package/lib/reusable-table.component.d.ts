import { AfterViewInit, ElementRef, EventEmitter, OnChanges, OnInit, SimpleChanges, ChangeDetectorRef } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { TableExportService } from './table-export.service';
import * as i0 from "@angular/core";
export interface ReUsableTableColumn {
    [x: string]: any;
    id: string;
    name: string;
    width?: string;
    type?: 'text' | 'integer' | 'number' | 'currency' | 'date' | 'actions' | 'chip' | 'multiline' | 'link';
    exportFormatter?: (value: any) => string;
    align?: 'left' | 'center' | 'right';
    digits?: string;
    style?: Record<string, any>;
    chipStyle?: Record<string, any>;
    chipStyleFn?: (value: any) => Record<string, any>;
    displayField?: string;
    linkField?: string;
    cellColor?: (value: any) => string;
    cellFontSize?: (value: any) => string;
    searchTextMode?: 'displayed' | 'all';
    actions?: {
        select?: {
            show?: boolean;
            tooltipText?: string;
            color?: 'primary' | 'accent' | 'warn';
            disableWhen?: {
                key: string;
                equals: any;
            };
            hideWhen?: {
                key: string;
                equals: any;
            };
        };
        edit?: {
            show?: boolean;
            tooltipText?: string;
            color?: 'primary' | 'accent' | 'warn';
            disableWhen?: {
                key: string;
                equals: any;
            };
            hideWhen?: {
                key: string;
                equals: any;
            };
        };
        delete?: {
            show?: boolean;
            tooltipText?: string;
            color?: 'primary' | 'accent' | 'warn';
            disableWhen?: {
                key: string;
                equals: any;
            };
            hideWhen?: {
                key: string;
                equals: any;
            };
        };
        settings?: {
            show?: boolean;
            tooltipText?: string;
            color?: 'primary' | 'accent' | 'warn';
            disableWhen?: {
                key: string;
                equals: any;
            };
            hideWhen?: {
                key: string;
                equals: any;
            };
        };
    };
    footer?: {
        type: 'sum' | 'avg' | 'min' | 'max' | 'count';
    } | {
        type: 'text';
        value: string;
    } | {
        type: 'custom';
        formatter: (rows: any[]) => string;
    };
}
export interface ReusableTableConfig {
    searchTextMode?: 'displayed' | 'all';
    appearance?: {
        zebraColor?: string;
        hoverColor?: string;
        selectedRowColor?: string;
        headingToPrint?: string;
    };
    typography?: {
        heading: string;
        cell: string;
    };
    pagination?: {
        enabled?: boolean;
        defaultPageSize?: 5 | 10 | 25 | 100;
    };
    sorting?: {
        enabled?: boolean;
    };
    toolbar?: {
        showSearch?: boolean;
        showColumnToggle?: boolean;
        showCsv?: boolean;
        showExcel?: boolean;
        showPdf?: boolean;
        showPrint?: boolean;
    };
    footer?: {
        enabled?: boolean;
        sticky?: boolean;
    };
    selection?: {
        multiSelect?: boolean;
    };
}
export declare class ReusableTableComponent implements OnInit, OnChanges, AfterViewInit {
    private readonly exportService;
    private readonly cdr;
    constructor(exportService: TableExportService, cdr: ChangeDetectorRef);
    columns: ReUsableTableColumn[];
    tableConfig: ReusableTableConfig;
    data: any[];
    paginator?: MatPaginator;
    sort?: MatSort;
    printSection?: ElementRef;
    rowEdit: EventEmitter<any>;
    rowSelect: EventEmitter<any>;
    rowDelete: EventEmitter<any>;
    rowSettings: EventEmitter<any>;
    selectedRows: any[];
    selectedRowsChange: EventEmitter<any[]>;
    resolvedConfig: Required<ReusableTableConfig>;
    isMobileView: boolean;
    displayedColumnIds: string[];
    displayedColumnsExtended: ReUsableTableColumn[];
    visibleColumnIds: string[];
    dataSource: MatTableDataSource<any, MatPaginator>;
    selectedRow: any;
    currentFilter: string;
    headingForCtrlP: string;
    footerValues: Record<string, string>;
    cellStyles: Record<string, Record<string, any>>;
    linkClick?: (item: any, event: Event) => void;
    ngOnInit(): void;
    updateViewMode(): void;
    ngOnChanges(changes: SimpleChanges): void;
    private initializeTable;
    private prepareCellStyles;
    ngAfterViewInit(): void;
    setSelectedRow(row: any): void;
    markRow(row: any): void;
    isRowSelected(row: any): boolean;
    isActionDisabled(row: any, action?: {
        disableWhen?: {
            key: string;
            equals: any;
        };
    }): boolean;
    isActionHide(row: any, action?: {
        hideWhen?: {
            key: string;
            equals: any;
        };
    }): boolean;
    getCellStyle(col: ReUsableTableColumn, row?: any): Record<string, any>;
    getChipContainerStyle(col: ReUsableTableColumn, value?: any): Record<string, any> | null;
    getChipTextStyle(col: ReUsableTableColumn, value?: any): Record<string, any> | null;
    getDisplayValue(obj: any, col: ReUsableTableColumn): any;
    getLinkValue(obj: any, col: ReUsableTableColumn): string;
    toggleColumn(columnId: string): void;
    onEdit(row: any): void;
    onSelect(row: any): void;
    onDelete(row: any): void;
    onSettings(row: any): void;
    applyGlobalFilter(event: Event): void;
    highlightSearchedText(value: any): string;
    private escapeHtml;
    private escapeRegex;
    getFormatOfValue(value: any, col: ReUsableTableColumn): string;
    printTable(): void;
    private mergeConfig;
    private buildSearchableText;
    private getSearchableCellText;
    private getSearchTextForObject;
    private attachMaterialControllers;
    private updateVisibleColumns;
    clearSelection(): void;
    private getExportData;
    private computeFooterValues;
    private calcFooterValue;
    private getFooterRowForExport;
    downloadCSV(): void;
    downloadExcel(): void;
    downloadPdf(): void;
    private assertHasRowsToExport;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReusableTableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReusableTableComponent, "app-reusabletable", never, { "columns": { "alias": "columns"; "required": false; }; "tableConfig": { "alias": "tableConfig"; "required": false; }; "data": { "alias": "data"; "required": false; }; "selectedRows": { "alias": "selectedRows"; "required": false; }; }, { "rowEdit": "rowEdit"; "rowSelect": "rowSelect"; "rowDelete": "rowDelete"; "rowSettings": "rowSettings"; "selectedRowsChange": "selectedRowsChange"; }, never, never, false, never>;
}
