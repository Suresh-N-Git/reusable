import * as i0 from '@angular/core';
import { Injectable, EventEmitter, Component, ChangeDetectionStrategy, Input, ViewChild, Output, HostListener, NgModule } from '@angular/core';
import * as i2 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i3 from '@angular/material/table';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import * as i4 from '@angular/material/paginator';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import * as i5 from '@angular/material/sort';
import { MatSort, MatSortModule } from '@angular/material/sort';
import * as i9 from '@angular/material/form-field';
import { MatFormFieldModule } from '@angular/material/form-field';
import * as i12 from '@angular/material/input';
import { MatInputModule } from '@angular/material/input';
import * as i6 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import * as i10 from '@angular/material/menu';
import { MatMenuModule } from '@angular/material/menu';
import * as i11 from '@angular/material/checkbox';
import { MatCheckboxModule } from '@angular/material/checkbox';
import * as i7 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import { MatTooltipModule } from '@angular/material/tooltip';
import * as i8 from '@angular/material/chips';
import { MatChipsModule } from '@angular/material/chips';
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

class TableExportService {
    exportCsv(columns, rows, footerRow) {
        const header = columns.map(c => `"${c.name}"`).join(',');
        const csvRows = rows.map(row => columns
            .map(col => {
            let value = row[col.id];
            if (col.exportFormatter) {
                value = col.exportFormatter(value);
            }
            if (value == null)
                return '';
            if (col.type === 'integer' || col.type === 'number' || col.type === 'currency') {
                return value;
            }
            return `"${value.toString().replace(/"/g, '""')}"`;
        })
            .join(','));
        const allLines = [header, ...csvRows];
        if (footerRow && footerRow.length) {
            const footerCsv = footerRow
                .map(value => `"${(value ?? '').toString().replace(/"/g, '""')}"`)
                .join(',');
            allLines.push(footerCsv);
        }
        const csvContent = allLines.join('\n');
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = 'table-export.csv';
        link.click();
    }
    exportExcel(columns, rows, footerRow) {
        const exportData = rows.map(row => {
            const obj = {};
            columns.forEach(col => {
                let value = row[col.id];
                if (col.exportFormatter) {
                    value = col.exportFormatter(value);
                }
                else if (Array.isArray(value)) {
                    value = value.join(', ');
                }
                else if (value && typeof value === 'object') {
                    value = JSON.stringify(value);
                }
                obj[col.name] = value;
            });
            return obj;
        });
        const worksheet = XLSX.utils.json_to_sheet(exportData);
        if (footerRow && footerRow.length) {
            XLSX.utils.sheet_add_aoa(worksheet, [footerRow], { origin: -1 });
        }
        const workbook = {
            Sheets: { Data: worksheet },
            SheetNames: ['Data'],
        };
        const excelBuffer = XLSX.write(workbook, {
            bookType: 'xlsx',
            type: 'array',
        });
        const blob = new Blob([excelBuffer], {
            type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = 'table-export.xlsx';
        link.click();
    }
    exportPdf(columns, rows, headingToPrint, formatter, footerRow) {
        const head = [columns.map(c => c.name)];
        const body = rows.map(row => columns.map(col => {
            const raw = row[col.id];
            let value = raw;
            if (col.exportFormatter) {
                value = col.exportFormatter(raw);
            }
            else if (formatter) {
                value = formatter(raw, col);
            }
            else if (Array.isArray(raw)) {
                value = raw.join(', ');
            }
            else if (raw && typeof raw === 'object') {
                value = JSON.stringify(raw);
            }
            else {
                value = raw ?? '';
            }
            return value;
        }));
        const doc = new jsPDF({
            orientation: columns.length > 6 ? 'landscape' : 'portrait',
        });
        const columnStyles = {};
        columns.forEach((col, index) => {
            columnStyles[index] = {
                halign: col.align || 'left',
            };
        });
        autoTable(doc, {
            head,
            body,
            foot: footerRow && footerRow.length ? [footerRow] : undefined,
            styles: { fontSize: 9 },
            columnStyles,
            headStyles: {
                fillColor: [41, 128, 185],
            },
            footStyles: {
                fillColor: [220, 220, 220],
                textColor: [0, 0, 0],
                fontStyle: 'bold',
            },
            margin: { top: 20 },
            didParseCell: (data) => {
                if (data.section === 'head' || data.section === 'foot') {
                    const colIndex = data.column.index;
                    data.cell.styles.halign = columnStyles[colIndex]?.halign || 'left';
                }
            },
            didDrawPage: () => {
                doc.setFontSize(12);
                doc.text(headingToPrint, 14, 15);
            },
        });
        doc.save('table-export.pdf');
    }
    // exportPdf(
    //   columns: ReUsableTableColumn[],
    //   rows: any[],
    //   headingToPrint: string,
    //   formatter?: (value: any, col: ReUsableTableColumn) => string
    // ): void {
    //   const head = [columns.map(c => c.name)];
    //   const body = rows.map(row =>
    //     columns.map(col => {
    //       const raw = row[col.id];
    //       let value = raw;
    //       if (col.exportFormatter) {
    //         value = col.exportFormatter(raw);
    //       } else if (formatter) {
    //         value = formatter(raw, col);
    //       } else if (Array.isArray(raw)) {
    //         value = raw.join(', ');
    //       } else if (raw && typeof raw === 'object') {
    //         value = JSON.stringify(raw);
    //       } else {
    //         value = raw ?? '';
    //       }
    //       return value;
    //     })
    //   );
    //   const doc = new jsPDF({
    //     orientation: columns.length > 6 ? 'landscape' : 'portrait',
    //   });
    //   const columnStyles: any = {};
    //   columns.forEach((col, index) => {
    //     columnStyles[index] = {
    //       halign: col.align || 'left',
    //     };
    //   });
    //   autoTable(doc, {
    //     head,
    //     body,
    //     styles: { fontSize: 9 },
    //     columnStyles,
    //     headStyles: {
    //       fillColor: [41, 128, 185],
    //     },
    //     margin: { top: 20 },
    //     didParseCell: (data: any) => {
    //       if (data.section === 'head') {
    //         const colIndex = data.column.index;
    //         data.cell.styles.halign = columnStyles[colIndex]?.halign || 'left';
    //       }
    //     },
    //     didDrawPage: () => {
    //       doc.setFontSize(12);
    //       doc.text(headingToPrint, 14, 15);
    //     },
    //   });
    //   doc.save('table-export.pdf');
    // }
    printTable(headingToPrint, html) {
        const popup = window.open('', '_blank', 'width=1000,height=700');
        if (!popup)
            return;
        popup.document.open();
        popup.document.write(`
    <html>
      <head>
        <title>${headingToPrint}</title>
        <style>
          body { font-family: Arial; margin:20px; }
          table { border-collapse: collapse; width:100%; }
          th, td { border:1px solid #ccc; padding:6px; }
          .mat-column-rowOps {display: none !important;}
          .mat-column-actions {display: none !important; }
        </style>
      </head>
       <body onload="window.focus(); window.print();">${html}</body>
    </html>
  `);
        popup.document.close();
        popup.onafterprint = () => popup.close();
        // popup.print();
        // popup.close();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: TableExportService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: TableExportService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: TableExportService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

const DEFAULT_TABLE_CONFIG = {
    searchTextMode: 'all',
    appearance: {
        zebraColor: '#f5f5f5',
        hoverColor: '#e3f2fd',
        selectedRowColor: '#ffe0b2',
        headingToPrint: 'Print Table'
    },
    typography: {
        heading: '1rem',
        cell: '1rem',
    },
    pagination: {
        enabled: true,
        defaultPageSize: 25,
    },
    sorting: {
        enabled: true,
    },
    toolbar: {
        showSearch: true,
        showColumnToggle: true,
        showCsv: true,
        showExcel: true,
        showPdf: true,
        showPrint: true,
    },
    footer: {
        enabled: false,
        sticky: false,
    },
    selection: {
        multiSelect: false,
    }
};
class ReusableTableComponent {
    exportService;
    cdr;
    constructor(exportService, cdr) {
        this.exportService = exportService;
        this.cdr = cdr;
    }
    columns = [];
    tableConfig = {};
    data = [];
    paginator;
    sort;
    printSection;
    rowEdit = new EventEmitter();
    rowSelect = new EventEmitter();
    rowDelete = new EventEmitter();
    rowSettings = new EventEmitter();
    // @Output() selectionChange = new EventEmitter<any[]>();
    // Pass true when you want to hide actions on the last row
    hideActionOnLastRow = false;
    selectedRows = [];
    selectedRowsChange = new EventEmitter();
    resolvedConfig = DEFAULT_TABLE_CONFIG;
    isMobileView = false;
    displayedColumnIds = [];
    displayedColumnsExtended = [];
    visibleColumnIds = [];
    dataSource = new MatTableDataSource([]);
    selectedRow = null; // For Single Row Click
    // selectedRows: any[] = []; // For Multi Row Click
    currentFilter = '';
    headingForCtrlP = "Print Table";
    footerValues = {};
    cellStyles = {};
    linkClick;
    ngOnInit() {
        this.updateViewMode();
    }
    updateViewMode() {
        this.isMobileView = window.innerWidth <= 768;
    }
    ngOnChanges(changes) {
        this.resolvedConfig = this.mergeConfig(this.tableConfig);
        if (changes['data']) {
            this.clearSelection();
        }
        // document.title = this.resolvedConfig.appearance.headingToPrint ?? this.headingForCtrlP;
        this.initializeTable();
    }
    initializeTable() {
        this.displayedColumnsExtended = [...this.columns];
        this.displayedColumnIds = this.columns.map(column => column.id);
        this.visibleColumnIds = [...this.displayedColumnIds];
        this.prepareCellStyles();
        this.dataSource = new MatTableDataSource(this.data ?? []);
        this.dataSource.filterPredicate = (data, filter) => this.buildSearchableText(data).includes(filter);
        this.updateVisibleColumns();
        this.attachMaterialControllers();
        this.computeFooterValues();
    }
    // private initializeTable(): void {
    //   this.displayedColumnsExtended = [...this.columns];
    //   this.displayedColumnIds = this.columns.map(column => column.id);
    //   this.visibleColumnIds = [...this.displayedColumnIds];
    //   this.dataSource = new MatTableDataSource(this.data ?? []);
    //   this.dataSource.filterPredicate = (data: any, filter: string) =>
    //     this.buildSearchableText(data).includes(filter);
    //   this.updateVisibleColumns();
    //   this.attachMaterialControllers();
    //   this.computeFooterValues();
    // }
    prepareCellStyles() {
        for (const row of this.data ?? []) {
            const styles = {};
            for (const col of this.columns) {
                const style = {
                    textAlign: col.align || 'left',
                    verticalAlign: 'middle',
                    ...col.style
                };
                if (row && col.cellColor) {
                    const color = col.cellColor(row[col.id]);
                    if (color) {
                        style['color'] = color;
                    }
                }
                if (row && col.cellFontSize) {
                    const fontSize = col.cellFontSize(row[col.id]);
                    if (fontSize) {
                        style['fontSize'] = fontSize;
                    }
                }
                // Store the style for every column
                styles[col.id] = style;
            }
            // Store all cell styles for this row
            row.__cellStyles = styles;
        }
    }
    ngAfterViewInit() {
        this.attachMaterialControllers();
    }
    // Select button — manages the multi-select set
    setSelectedRow(row) {
        if (this.resolvedConfig.selection?.multiSelect) {
            const idx = this.selectedRows.indexOf(row);
            const next = idx >= 0
                ? this.selectedRows.filter((_, i) => i !== idx)
                : [...this.selectedRows, row];
            this.selectedRowsChange.emit(next); // emit, parent updates its array
        }
        else {
            this.selectedRow = row; // single-mode internal highlight
        }
    }
    markRow(row) {
        if (!this.resolvedConfig.selection?.multiSelect) {
            this.selectedRow = row;
        }
        // multi-mode: do nothing — edit/delete don't affect the highlight set
    }
    isRowSelected(row) {
        if (this.resolvedConfig.selection?.multiSelect) {
            return this.selectedRows.includes(row); // reads from input
        }
        return row === this.selectedRow; // internal single-mode highlight
    }
    isActionDisabled(row, action) {
        const rule = action?.disableWhen;
        if (!rule)
            return false;
        return row[rule.key] === rule.equals;
    }
    isActionHide(row, action) {
        const rule = action?.hideWhen;
        if (!rule)
            return false;
        return row[rule.key] === rule.equals;
    }
    getCellStyle(col, row) {
        const style = {
            textAlign: col.align || 'left',
            verticalAlign: 'middle',
            ...col.style
        };
        if (row && col.cellColor) {
            const value = row[col.id];
            const color = col.cellColor(value);
            if (color) {
                style['color'] = color;
            }
        }
        return style;
    }
    getChipContainerStyle(col, value) {
        const style = col.chipStyleFn ? col.chipStyleFn(value) : col.chipStyle;
        if (!style)
            return null;
        return { backgroundColor: style['backgroundColor'] };
    }
    getChipTextStyle(col, value) {
        const style = col.chipStyleFn ? col.chipStyleFn(value) : col.chipStyle;
        if (!style)
            return null;
        const { backgroundColor, ...rest } = style;
        return rest;
    }
    getDisplayValue(obj, col) {
        if (!obj)
            return '';
        if (col.displayField) {
            return obj[col.displayField];
        }
        return Object.values(obj).find(value => value != null) ?? '';
    }
    getLinkValue(obj, col) {
        if (!obj)
            return '';
        return col.linkField ? obj[col.linkField] : obj;
    }
    toggleColumn(columnId) {
        const index = this.visibleColumnIds.indexOf(columnId);
        if (index >= 0) {
            this.visibleColumnIds.splice(index, 1);
        }
        else {
            this.visibleColumnIds.push(columnId);
        }
        this.updateVisibleColumns();
        this.computeFooterValues();
    }
    onEdit(row) {
        this.rowEdit.emit(row);
    }
    onSelect(row) {
        this.rowSelect.emit(row);
    }
    onDelete(row) {
        this.rowDelete.emit(row);
    }
    onSettings(row) {
        this.rowSettings.emit(row);
    }
    applyGlobalFilter(event) {
        const value = event.target.value.trim().toLowerCase();
        this.currentFilter = value;
        this.dataSource.filter = value;
        this.dataSource.paginator?.firstPage();
        this.computeFooterValues();
    }
    //  A few notes onn highlightSearchedText
    // Order matters in escapeHtml. & has to be replaced first — otherwise escaping < to &lt; would double-encode any existing & in later passes.
    // escapeRegex covers every regex metacharacter (. * + ? ^ $ { } ( ) | [ ] \). After this, a user typing (abc or . in the search box matches literal text instead of exploding or matching everything.
    // Guard clause widened a bit. The old if (!value ...) treated 0 and '' as "nothing to do" and returned them unchanged, which then got run through [innerHTML]. The new check is explicit about null/undefined and always returns a string-safe result.
    // Both helpers are private because they're implementation details, not part of the public API.
    // The template binding stays the same. You don't need to touch any [innerHTML]="highlightSearchedText(...)" in the HTML — they just start emitting safe content.
    highlightSearchedText(value) {
        if (value === null || value === undefined || !this.currentFilter) {
            return value ?? '';
        }
        const escapedValue = this.escapeHtml(String(value));
        const escapedFilter = this.escapeRegex(this.currentFilter);
        const regex = new RegExp(`(${escapedFilter})`, 'gi');
        return escapedValue.replace(regex, '<mark>$1</mark>');
    }
    escapeHtml(text) {
        return text
            .replace(/&/g, '&amp;') // must be first
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }
    escapeRegex(text) {
        return text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }
    getFormatOfValue(value, col) {
        if (value === null || value === undefined)
            return '';
        switch (col.type) {
            case 'integer':
                return Number(value).toLocaleString(undefined, {
                    maximumFractionDigits: 0,
                });
            case 'number': {
                if (!col.digits)
                    return Number(value).toLocaleString();
                const parts = col.digits.split('.');
                const fraction = parts[1]?.split('-');
                const minFraction = Number(fraction?.[0] ?? 0);
                const maxFraction = Number(fraction?.[1] ?? minFraction);
                return Number(value).toLocaleString(undefined, {
                    minimumFractionDigits: minFraction,
                    maximumFractionDigits: maxFraction,
                });
            }
            default:
                return String(value);
        }
    }
    printTable() {
        const { rows } = this.getExportData();
        if (!this.assertHasRowsToExport(rows))
            return;
        const savedPaginator = this.dataSource.paginator;
        this.dataSource.paginator = null; // Set it to null so that the whole data source gets printed
        this.cdr.detectChanges(); // Needed to make the full table data available in the html
        const html = this.printSection?.nativeElement?.innerHTML;
        this.dataSource.paginator = savedPaginator; // Put back the original state of the paginator
        this.cdr.detectChanges(); // Change detection then puts back the no of rows originally visible
        if (!html)
            return;
        this.exportService.printTable(this.resolvedConfig.appearance.headingToPrint, html);
    }
    mergeConfig(config) {
        return {
            searchTextMode: config.searchTextMode ?? DEFAULT_TABLE_CONFIG.searchTextMode,
            appearance: {
                ...DEFAULT_TABLE_CONFIG.appearance,
                ...(config.appearance ?? {}),
            },
            typography: {
                ...DEFAULT_TABLE_CONFIG.typography,
                ...(config.typography ?? {})
            },
            pagination: {
                ...DEFAULT_TABLE_CONFIG.pagination,
                ...(config.pagination ?? {}),
            },
            sorting: {
                ...DEFAULT_TABLE_CONFIG.sorting,
                ...(config.sorting ?? {}),
            },
            toolbar: {
                ...DEFAULT_TABLE_CONFIG.toolbar,
                ...(config.toolbar ?? {}),
            },
            footer: {
                ...DEFAULT_TABLE_CONFIG.footer,
                ...(config.footer ?? {}),
            },
            selection: {
                ...DEFAULT_TABLE_CONFIG.selection,
                ...(config.selection ?? {}),
            },
        };
    }
    buildSearchableText(row) {
        return this.displayedColumnsExtended
            .map(column => this.getSearchableCellText(row?.[column.id], column))
            .join(' ')
            .toLowerCase();
    }
    getSearchableCellText(value, col) {
        if (value === null || value === undefined)
            return '';
        if (Array.isArray(value)) {
            return value
                .map(item => {
                if (item && typeof item === 'object') {
                    return this.getSearchTextForObject(item, col);
                }
                return String(item);
            })
                .join(' ');
        }
        if (value && typeof value === 'object') {
            return this.getSearchTextForObject(value, col);
        }
        return String(value);
    }
    getSearchTextForObject(obj, col) {
        const displayedText = String(this.getDisplayValue(obj, col) ?? '');
        const hiddenText = String(this.getLinkValue(obj, col) ?? '');
        if (this.resolvedConfig.searchTextMode === 'displayed') {
            return displayedText;
        }
        return [displayedText, hiddenText].filter(Boolean).join(' ');
    }
    attachMaterialControllers() {
        if (this.paginator && this.resolvedConfig.pagination.enabled) {
            this.dataSource.paginator = this.paginator;
            const len = this.dataSource.data.length;
            const pageSize = this.resolvedConfig.pagination.defaultPageSize ?? 25;
            this.paginator.pageSize = len < pageSize ? (len || 1) : pageSize;
            this.paginator.firstPage();
        }
        if (this.sort && this.resolvedConfig.sorting.enabled) {
            this.dataSource.sort = this.sort;
        }
    }
    updateVisibleColumns() {
        const actionsCol = this.displayedColumnsExtended.find(col => col.type === 'actions');
        if (actionsCol && !this.visibleColumnIds.includes(actionsCol.id)) {
            this.visibleColumnIds.push(actionsCol.id);
        }
        this.displayedColumnIds = this.displayedColumnsExtended
            .filter(column => this.visibleColumnIds.includes(column.id))
            .map(column => column.id);
    }
    clearSelection() {
        this.selectedRow = null;
        if (this.selectedRows.length > 0) {
            this.selectedRows = [];
            this.selectedRowsChange.emit([]);
        }
        // this.cdr.detectChanges();
        this.cdr.markForCheck();
    }
    getExportData() {
        const columns = this.displayedColumnsExtended.filter(column => this.displayedColumnIds.includes(column.id) && column.type !== 'actions');
        const rows = this.dataSource.filteredData;
        return { columns, rows };
    }
    computeFooterValues() {
        if (!this.resolvedConfig.footer.enabled) {
            this.footerValues = {};
            return;
        }
        const rows = this.dataSource.filteredData ?? [];
        const next = {};
        for (const col of this.displayedColumnsExtended) {
            next[col.id] = this.calcFooterValue(col, rows);
        }
        this.footerValues = next;
    }
    calcFooterValue(col, rows) {
        if (!col.footer)
            return '';
        switch (col.footer.type) {
            case 'text':
                return col.footer.value;
            case 'custom':
                return col.footer.formatter(rows);
            case 'count':
                return String(rows.length);
            case 'sum':
            case 'avg':
            case 'min':
            case 'max': {
                const nums = rows
                    .map(r => Number(r?.[col.id]))
                    .filter(n => Number.isFinite(n));
                // if (!nums.length) return '';
                if (!nums.length) {
                    console.warn(`[ReusableTable] footer type "${col.footer.type}" on column "${col.id}" ` +
                        `found no numeric values — rendering empty. Check if the column holds numeric data.`);
                    return '';
                }
                let result;
                switch (col.footer.type) {
                    case 'sum':
                        result = nums.reduce((a, b) => a + b, 0);
                        break;
                    case 'avg':
                        result = nums.reduce((a, b) => a + b, 0) / nums.length;
                        break;
                    case 'min':
                        result = Math.min(...nums);
                        break;
                    case 'max':
                        result = Math.max(...nums);
                        break;
                }
                return this.getFormatOfValue(result, col);
            }
        }
    }
    getFooterRowForExport(columns) {
        if (!this.resolvedConfig.footer.enabled)
            return null;
        return columns.map(col => this.footerValues[col.id] ?? '');
    }
    downloadCSV() {
        const { columns, rows } = this.getExportData();
        if (!this.assertHasRowsToExport(rows))
            return;
        const footerRow = this.getFooterRowForExport(columns);
        this.exportService.exportCsv(columns, rows, footerRow);
    }
    downloadExcel() {
        const { columns, rows } = this.getExportData();
        if (!this.assertHasRowsToExport(rows))
            return;
        const footerRow = this.getFooterRowForExport(columns);
        this.exportService.exportExcel(columns, rows, footerRow);
    }
    downloadPdf() {
        const { columns, rows } = this.getExportData();
        if (!this.assertHasRowsToExport(rows))
            return;
        const footerRow = this.getFooterRowForExport(columns);
        this.exportService.exportPdf(columns, rows, this.resolvedConfig.appearance.headingToPrint, (value, col) => this.getFormatOfValue(value, col), footerRow);
    }
    assertHasRowsToExport(rows) {
        if (rows.length === 0) {
            alert('No Data Found.');
            return false;
        }
        return true;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: ReusableTableComponent, deps: [{ token: TableExportService }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.14", type: ReusableTableComponent, selector: "app-reusabletable", inputs: { columns: "columns", tableConfig: "tableConfig", data: "data", hideActionOnLastRow: "hideActionOnLastRow", selectedRows: "selectedRows" }, outputs: { rowEdit: "rowEdit", rowSelect: "rowSelect", rowDelete: "rowDelete", rowSettings: "rowSettings", selectedRowsChange: "selectedRowsChange" }, host: { listeners: { "window:resize": "updateViewMode()" } }, viewQueries: [{ propertyName: "paginator", first: true, predicate: MatPaginator, descendants: true }, { propertyName: "sort", first: true, predicate: MatSort, descendants: true }, { propertyName: "printSection", first: true, predicate: ["printSection"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<div class=\"row w-100 align-items-center no-print\">\r\n  <div class=\"col-md-3 col-sm-12\">\r\n    <mat-form-field *ngIf=\"resolvedConfig.toolbar.showSearch\" appearance=\"outline\" class=\"search-field\">\r\n      <mat-label>Search</mat-label>\r\n      <mat-icon matSuffix>search</mat-icon>\r\n      <input matInput (keyup)=\"applyGlobalFilter($event)\" placeholder=\"Search all columns\">\r\n    </mat-form-field>\r\n  </div>\r\n\r\n\r\n  <div class=\"col-md-9\" style=\"text-align: right;\">\r\n    <button *ngIf=\"resolvedConfig.toolbar.showColumnToggle !== false\" mat-icon-button color=\"primary\"\r\n      [matMenuTriggerFor]=\"columnMenu\" title=\"Show/Hide Columns\">\r\n      <mat-icon class=\"toolbaricons\">view_week</mat-icon>\r\n      <span class=\"icon-text\" style=\"margin-top: 0px;\">shc</span>\r\n    </button>\r\n\r\n    <button *ngIf=\"resolvedConfig.toolbar.showCsv\" mat-icon-button color=\"primary\" title=\"Download CSV\"\r\n      (click)=\"downloadCSV()\">\r\n      <mat-icon class=\"toolbaricons\">description</mat-icon>\r\n      <span class=\"icon-text\">csv</span>\r\n    </button>\r\n\r\n    <button *ngIf=\"resolvedConfig.toolbar.showExcel !== false\" mat-icon-button color=\"primary\" title=\"Download Excel\"\r\n      (click)=\"downloadExcel()\">\r\n      <mat-icon class=\"toolbaricons\">table_view</mat-icon>\r\n      <span class=\"icon-text\">xls</span>\r\n    </button>\r\n\r\n    <button *ngIf=\"resolvedConfig.toolbar.showPdf !== false\" mat-icon-button color=\"primary\" title=\"Download PDF\"\r\n      (click)=\"downloadPdf()\">\r\n      <mat-icon class=\"toolbaricons\">picture_as_pdf</mat-icon>\r\n      <span class=\"icon-text\">pdf</span>\r\n    </button>\r\n\r\n    <button *ngIf=\"resolvedConfig.toolbar.showPrint\" mat-icon-button color=\"primary\" title=\"Print Table\"\r\n      (click)=\"printTable()\">\r\n      <mat-icon class=\"toolbaricons\">print</mat-icon>\r\n      <span class=\"icon-text\">prn</span>\r\n    </button>\r\n\r\n  </div>\r\n\r\n\r\n  <mat-menu #columnMenu=\"matMenu\" class=\"column-menu\">\r\n\r\n    <div class=\"menu-header\">\r\n      <span>Show Columns</span>\r\n    </div>\r\n\r\n    @for (col of displayedColumnsExtended; track col.id) {\r\n    <button mat-menu-item (click)=\"$event.stopPropagation()\">\r\n      <mat-checkbox [checked]=\"visibleColumnIds.includes(col.id)\" (change)=\"toggleColumn(col.id)\"\r\n        [disabled]=\"col.type === 'actions'\">\r\n        {{ col.name }}\r\n      </mat-checkbox>\r\n    </button>\r\n    }\r\n\r\n  </mat-menu>\r\n\r\n</div>\r\n\r\n<div #printSection class=\"table-container print-area no-print\"\r\n  [style.--zebra-color]=\"resolvedConfig.appearance.zebraColor\"\r\n  [style.--hover-color]=\"resolvedConfig.appearance.hoverColor || '#e3f2fd'\"\r\n  [style.--selected-row-color]=\"resolvedConfig.appearance.selectedRowColor || '#ffe0b2'\">\r\n\r\n  <table mat-table [dataSource]=\"dataSource\" matSort>\r\n\r\n    @for (col of displayedColumnsExtended; track col.id) {\r\n\r\n    <ng-container [matColumnDef]=\"col.id\">\r\n\r\n      @if (col.type !== 'actions') {\r\n      <th mat-header-cell *matHeaderCellDef [style.width]=\"col.width\" mat-sort-header\r\n        [style.font-size]=\"tableConfig.typography?.heading\" [disabled]=\"!resolvedConfig.sorting.enabled\"\r\n        [arrowPosition]=\"col.align === 'right' ? 'before' : 'after'\" [ngClass]=\"{\r\n          'right-aligned-header': col.align === 'right',\r\n          'center-aligned-header': col.align === 'center',\r\n          'left-aligned-header': !col.align || col.align === 'left'\r\n        }\">\r\n        {{ col.name }}\r\n      </th>\r\n      } @else {\r\n      <th mat-header-cell *matHeaderCellDef [style.width]=\"col.width\"\r\n        [style.font-size]=\"tableConfig.typography?.heading\" [style.text-align]=\"col.align || 'left'\">\r\n        {{ col.name }}\r\n      </th>\r\n      }\r\n\r\n      <td mat-cell *matCellDef=\"let row let i=index\" [attr.data-label]=\"col.name\"\r\n        [style.font-size]=\"tableConfig.typography?.cell\" [ngStyle]=\"row.__cellStyles?.[col.id]\">\r\n\r\n        @if (col.type === 'actions') {\r\n\r\n        @if (isMobileView) {\r\n        <span class=\"cell-label\">{{ col.name }}</span>\r\n        }\r\n\r\n        @if (!(hideActionOnLastRow && i === dataSource.data.length - 1)) {\r\n\r\n        <div class=\"cell-value action-buttons\">\r\n          @if (col.actions?.select?.show && !isActionHide(row, col.actions?.select)) {\r\n          <button mat-icon-button [color]=\"col.actions?.select?.color\"\r\n            [disabled]=\"isActionDisabled(row, col.actions?.select)\" (click)=\"setSelectedRow(row); onSelect(row)\">\r\n            <mat-icon [title]=\"col.actions?.select?.tooltipText ?? 'Select'\">check_circle_outline</mat-icon>\r\n          </button>\r\n          }\r\n\r\n          @if (col.actions?.edit?.show && !isActionHide(row, col.actions?.edit)) {\r\n          <button mat-icon-button [color]=\"col.actions?.edit?.color\"\r\n            [disabled]=\"isActionDisabled(row, col.actions?.edit)\" (click)=\"markRow(row); onEdit(row)\">\r\n            <mat-icon [title]=\"col.actions?.edit?.tooltipText ?? 'Edit'\">edit</mat-icon>\r\n          </button>\r\n          }\r\n\r\n          @if (col.actions?.delete?.show && !isActionHide(row, col.actions?.delete)) {\r\n          <button mat-icon-button [color]=\"col.actions?.delete?.color\"\r\n            [disabled]=\"isActionDisabled(row, col.actions?.delete)\" (click)=\"markRow(row); onDelete(row)\">\r\n            <mat-icon [title]=\"col.actions?.delete?.tooltipText ?? 'Delete'\">delete</mat-icon>\r\n          </button>\r\n          }\r\n          @if (col.actions?.settings?.show && !isActionHide(row, col.actions?.settings)) {\r\n          <button mat-icon-button [color]=\"col.actions?.select?.color\"\r\n            [disabled]=\"isActionDisabled(row, col.actions?.settings)\" (click)=\"markRow(row); onSettings(row)\">\r\n            <mat-icon [title]=\"col.actions?.settings?.tooltipText ?? 'Settings'\">settings</mat-icon>\r\n          </button>\r\n          }\r\n        </div>\r\n        }\r\n\r\n        } @else {\r\n\r\n        @if (isMobileView) {\r\n        <span class=\"cell-label\">{{ col.name }}</span>\r\n        }\r\n\r\n        <span class=\"cell-value\">\r\n\r\n          @switch (col.type) {\r\n\r\n          @case ('integer') {\r\n          {{ row[col.id] | number:'1.0-0' }}\r\n          }\r\n\r\n          @case ('number') {\r\n          <span [innerHTML]=\"highlightSearchedText(row[col.id] | number:(col.digits || '1.2-2'))\"></span>\r\n          }\r\n\r\n          @case ('currency') {\r\n          {{ row[col.id] | currency:'INR' }}\r\n          }\r\n\r\n          @case ('date') {\r\n          {{ row[col.id] | date:'dd-MM-yyyy' }}\r\n          }\r\n\r\n          <!-- @case ('chip') {\r\n          <mat-chip selected [ngStyle]=\"getChipContainerStyle(col)\">\r\n            <span [ngStyle]=\"getChipTextStyle(col)\">\r\n              {{ row[col.id] }}\r\n            </span>\r\n          </mat-chip>\r\n          } -->\r\n\r\n          @case ('chip') {\r\n          <mat-chip [ngStyle]=\"getChipContainerStyle(col, row[col.id])\">\r\n            <span [ngStyle]=\"getChipTextStyle(col, row[col.id])\">\r\n              {{ row[col.id] }}\r\n            </span>\r\n          </mat-chip>\r\n          }\r\n\r\n          @case ('multiline') {\r\n          <ng-container *ngIf=\"row[col.id]?.length; else noData\">\r\n            <div *ngFor=\"let item of row[col.id]\">\r\n              {{ getDisplayValue(item, col) }}\r\n            </div>\r\n          </ng-container>\r\n          <ng-template #noData>-</ng-template>\r\n          }\r\n\r\n          @case ('link') {\r\n          <ng-container *ngIf=\"row[col.id]?.length; else noData\">\r\n            <div *ngFor=\"let item of row[col.id]\" class=\"file-link-row\">\r\n              <a href=\"#\" (click)=\"col['linkClick']\r\n                  ? col['linkClick'](item, $event)\r\n                  : null\">\r\n                {{ getDisplayValue(item, col) }}\r\n              </a>\r\n              <!-- <a [href]=\"getLinkValue(item, col)\" target=\"_blank\" rel=\"noopener noreferrer\">\r\n                {{ getDisplayValue(item, col) }}\r\n              </a> -->\r\n            </div>\r\n          </ng-container>\r\n          <ng-template #noData>-</ng-template>\r\n          }\r\n\r\n          @default {\r\n          <span [innerHTML]=\"highlightSearchedText(row[col.id])\"></span>\r\n          }\r\n\r\n          }\r\n\r\n        </span>\r\n\r\n        }\r\n\r\n      </td>\r\n\r\n      <td mat-footer-cell *matFooterCellDef [ngStyle]=\"getCellStyle(col)\">\r\n        {{ footerValues[col.id] }}\r\n      </td>\r\n\r\n    </ng-container>\r\n\r\n    }\r\n\r\n    <tr mat-header-row *matHeaderRowDef=\"displayedColumnIds; sticky: true\"></tr>\r\n    <!-- <tr mat-row *matRowDef=\"let row; columns: displayedColumnIds\" [class.row-selected]=\"row === selectedRow\"></tr> -->\r\n\r\n    <!-- for Multi Row Select -->\r\n    <tr mat-row *matRowDef=\"let row; columns: displayedColumnIds\" [class.row-selected]=\"isRowSelected(row)\"></tr>\r\n\r\n    @if (resolvedConfig.footer.enabled) {\r\n    <tr mat-footer-row *matFooterRowDef=\"displayedColumnIds; sticky: resolvedConfig.footer.sticky\"></tr>\r\n    }\r\n\r\n  </table>\r\n</div>\r\n\r\n<div class=\"no-print\" *ngIf=\"resolvedConfig.pagination.enabled\">\r\n  <mat-paginator [pageSizeOptions]=\"[5, 10, 25, 100]\" showFirstLastButtons></mat-paginator>\r\n</div>\r\n\r\n<div class=\"print-hint no-print\" *ngIf=\"(displayedColumnIds.length || 0) > 7\">\r\n  For reports with more than 7 columns, select\r\n  <b>Landscape</b> in the print dialog.\r\n</div>", styles: [".table-container{height:500px;overflow:auto;border:1px solid #ddd}.search-field{width:100%}.search-field .mat-mdc-form-field-infix{padding-top:10px;padding-bottom:10px}.mat-mdc-header-row{background:#fff;box-shadow:0 2px 3px #00000014;z-index:10}.mat-mdc-header-row .mat-mdc-header-cell{background:#94baf3;border-bottom:1px solid #dcdcdc;font-weight:600;letter-spacing:3px;font-variant-numeric:tabular-nums}.mat-mdc-header-cell,.mat-mdc-cell,.mat-sort-header-content{font-variant-numeric:tabular-nums}.mat-sort-header-content{letter-spacing:inherit}.table-container .mat-mdc-row:nth-child(2n){background:var(--zebra-color)}.table-container .mat-mdc-row:hover .mat-mdc-cell{background:var(--hover-color)!important}.table-container .mat-mdc-row.row-selected .mat-mdc-cell,.table-container .mat-mdc-row.row-selected:hover .mat-mdc-cell{background:var(--selected-row-color)!important}.table-container .mat-mdc-cell,.table-container .mat-mdc-header-cell{padding-top:0!important;padding-bottom:0!important}.button-container{display:flex;justify-content:space-evenly;align-items:center;padding:20px}.mdc-data-table__cell,.mat-mdc-header-cell{padding:12px 16px}.cell-label{display:none}.cell-value{display:block;width:100%;margin-top:0}.mat-column-flow .cell-value,.mat-column-id .cell-value{padding-right:0}.table-container .mat-column-actions .cell-value{display:flex;align-items:center;justify-content:center}mark{background:#ffeb3b;border-radius:2px;padding:0 2px}button.mat-icon-button{display:flex;flex-direction:column;align-items:center;justify-content:center}.icon-text{font-size:14px;line-height:14px}.toolbaricons{margin:0}.action-buttons{display:flex;align-items:center;justify-content:center;gap:2px}.action-buttons mat-icon{width:24px;height:24px;font-size:24px}.action-buttons .mat-mdc-icon-button{width:28px;height:28px;padding:2px}.print-hint{margin-top:6px;color:#555;font-size:12px}.column-menu{padding:8px 0}.menu-header{padding:8px 16px;border-bottom:1px solid #ddd;font-weight:600}.mat-menu-item{height:auto}@media screen and (max-width: 768px){.mat-mdc-header-row{display:none!important}mat-form-field{width:100%}.mat-mdc-row{display:block!important;margin:16px 0;padding:12px;border:1px solid #e0e0e0;border-radius:8px;background:#fff;height:auto!important;min-height:unset!important}.mat-mdc-cell{display:flex!important;justify-content:flex-start!important;width:100%;padding:8px 0!important;text-align:left!important;border-bottom:1px solid #eee}.mat-mdc-footer-row{display:none!important}.mat-mdc-cell:last-child{border-bottom:none}.mat-mdc-cell:before{content:none}.cell-label{display:block;flex:0 0 40%;font-weight:600;color:#666;text-transform:uppercase}.cell-value{margin-left:auto!important;min-width:0;text-align:right!important;font-variant-numeric:tabular-nums}}@media print{body *,.no-print,.mat-column-actions{display:none!important}.print-area,.print-area *{visibility:visible}.print-area{position:absolute;left:0;top:0;width:100%}.table-container{height:auto!important;overflow:visible!important}}.table-container .mat-mdc-chip{--mdc-chip-container-height: 22px;--mdc-chip-label-text-size: 11px;--mdc-chip-container-shape-radius: 8px}.file-link-row{margin-bottom:.6rem}.file-link-row:last-child{margin-bottom:0}\n"], dependencies: [{ kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i2.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i2.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "component", type: i3.MatTable, selector: "mat-table, table[mat-table]", exportAs: ["matTable"] }, { kind: "directive", type: i3.MatHeaderCellDef, selector: "[matHeaderCellDef]" }, { kind: "directive", type: i3.MatHeaderRowDef, selector: "[matHeaderRowDef]", inputs: ["matHeaderRowDef", "matHeaderRowDefSticky"] }, { kind: "directive", type: i3.MatColumnDef, selector: "[matColumnDef]", inputs: ["matColumnDef"] }, { kind: "directive", type: i3.MatCellDef, selector: "[matCellDef]" }, { kind: "directive", type: i3.MatRowDef, selector: "[matRowDef]", inputs: ["matRowDefColumns", "matRowDefWhen"] }, { kind: "directive", type: i3.MatFooterCellDef, selector: "[matFooterCellDef]" }, { kind: "directive", type: i3.MatFooterRowDef, selector: "[matFooterRowDef]", inputs: ["matFooterRowDef", "matFooterRowDefSticky"] }, { kind: "directive", type: i3.MatHeaderCell, selector: "mat-header-cell, th[mat-header-cell]" }, { kind: "directive", type: i3.MatCell, selector: "mat-cell, td[mat-cell]" }, { kind: "directive", type: i3.MatFooterCell, selector: "mat-footer-cell, td[mat-footer-cell]" }, { kind: "component", type: i3.MatHeaderRow, selector: "mat-header-row, tr[mat-header-row]", exportAs: ["matHeaderRow"] }, { kind: "component", type: i3.MatRow, selector: "mat-row, tr[mat-row]", exportAs: ["matRow"] }, { kind: "component", type: i3.MatFooterRow, selector: "mat-footer-row, tr[mat-footer-row]", exportAs: ["matFooterRow"] }, { kind: "component", type: i4.MatPaginator, selector: "mat-paginator", inputs: ["color", "pageIndex", "length", "pageSize", "pageSizeOptions", "hidePageSize", "showFirstLastButtons", "selectConfig", "disabled"], outputs: ["page"], exportAs: ["matPaginator"] }, { kind: "directive", type: i5.MatSort, selector: "[matSort]", inputs: ["matSortActive", "matSortStart", "matSortDirection", "matSortDisableClear", "matSortDisabled"], outputs: ["matSortChange"], exportAs: ["matSort"] }, { kind: "component", type: i5.MatSortHeader, selector: "[mat-sort-header]", inputs: ["mat-sort-header", "arrowPosition", "start", "disabled", "sortActionDescription", "disableClear"], exportAs: ["matSortHeader"] }, { kind: "component", type: i6.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: i7.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "component", type: i8.MatChip, selector: "mat-basic-chip, [mat-basic-chip], mat-chip, [mat-chip]", inputs: ["role", "id", "aria-label", "aria-description", "value", "color", "removable", "highlighted", "disableRipple", "disabled"], outputs: ["removed", "destroyed"], exportAs: ["matChip"] }, { kind: "component", type: i9.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i9.MatLabel, selector: "mat-label" }, { kind: "directive", type: i9.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "component", type: i10.MatMenu, selector: "mat-menu", inputs: ["backdropClass", "aria-label", "aria-labelledby", "aria-describedby", "xPosition", "yPosition", "overlapTrigger", "hasBackdrop", "class", "classList"], outputs: ["closed", "close"], exportAs: ["matMenu"] }, { kind: "component", type: i10.MatMenuItem, selector: "[mat-menu-item]", inputs: ["role", "disabled", "disableRipple"], exportAs: ["matMenuItem"] }, { kind: "directive", type: i10.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", inputs: ["mat-menu-trigger-for", "matMenuTriggerFor", "matMenuTriggerData", "matMenuTriggerRestoreFocus"], outputs: ["menuOpened", "onMenuOpen", "menuClosed", "onMenuClose"], exportAs: ["matMenuTrigger"] }, { kind: "component", type: i11.MatCheckbox, selector: "mat-checkbox", inputs: ["aria-label", "aria-labelledby", "aria-describedby", "id", "required", "labelPosition", "name", "value", "disableRipple", "tabIndex", "color", "disabledInteractive", "checked", "disabled", "indeterminate"], outputs: ["change", "indeterminateChange"], exportAs: ["matCheckbox"] }, { kind: "directive", type: i12.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly"], exportAs: ["matInput"] }, { kind: "pipe", type: i2.DecimalPipe, name: "number" }, { kind: "pipe", type: i2.CurrencyPipe, name: "currency" }, { kind: "pipe", type: i2.DatePipe, name: "date" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: ReusableTableComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-reusabletable', changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"row w-100 align-items-center no-print\">\r\n  <div class=\"col-md-3 col-sm-12\">\r\n    <mat-form-field *ngIf=\"resolvedConfig.toolbar.showSearch\" appearance=\"outline\" class=\"search-field\">\r\n      <mat-label>Search</mat-label>\r\n      <mat-icon matSuffix>search</mat-icon>\r\n      <input matInput (keyup)=\"applyGlobalFilter($event)\" placeholder=\"Search all columns\">\r\n    </mat-form-field>\r\n  </div>\r\n\r\n\r\n  <div class=\"col-md-9\" style=\"text-align: right;\">\r\n    <button *ngIf=\"resolvedConfig.toolbar.showColumnToggle !== false\" mat-icon-button color=\"primary\"\r\n      [matMenuTriggerFor]=\"columnMenu\" title=\"Show/Hide Columns\">\r\n      <mat-icon class=\"toolbaricons\">view_week</mat-icon>\r\n      <span class=\"icon-text\" style=\"margin-top: 0px;\">shc</span>\r\n    </button>\r\n\r\n    <button *ngIf=\"resolvedConfig.toolbar.showCsv\" mat-icon-button color=\"primary\" title=\"Download CSV\"\r\n      (click)=\"downloadCSV()\">\r\n      <mat-icon class=\"toolbaricons\">description</mat-icon>\r\n      <span class=\"icon-text\">csv</span>\r\n    </button>\r\n\r\n    <button *ngIf=\"resolvedConfig.toolbar.showExcel !== false\" mat-icon-button color=\"primary\" title=\"Download Excel\"\r\n      (click)=\"downloadExcel()\">\r\n      <mat-icon class=\"toolbaricons\">table_view</mat-icon>\r\n      <span class=\"icon-text\">xls</span>\r\n    </button>\r\n\r\n    <button *ngIf=\"resolvedConfig.toolbar.showPdf !== false\" mat-icon-button color=\"primary\" title=\"Download PDF\"\r\n      (click)=\"downloadPdf()\">\r\n      <mat-icon class=\"toolbaricons\">picture_as_pdf</mat-icon>\r\n      <span class=\"icon-text\">pdf</span>\r\n    </button>\r\n\r\n    <button *ngIf=\"resolvedConfig.toolbar.showPrint\" mat-icon-button color=\"primary\" title=\"Print Table\"\r\n      (click)=\"printTable()\">\r\n      <mat-icon class=\"toolbaricons\">print</mat-icon>\r\n      <span class=\"icon-text\">prn</span>\r\n    </button>\r\n\r\n  </div>\r\n\r\n\r\n  <mat-menu #columnMenu=\"matMenu\" class=\"column-menu\">\r\n\r\n    <div class=\"menu-header\">\r\n      <span>Show Columns</span>\r\n    </div>\r\n\r\n    @for (col of displayedColumnsExtended; track col.id) {\r\n    <button mat-menu-item (click)=\"$event.stopPropagation()\">\r\n      <mat-checkbox [checked]=\"visibleColumnIds.includes(col.id)\" (change)=\"toggleColumn(col.id)\"\r\n        [disabled]=\"col.type === 'actions'\">\r\n        {{ col.name }}\r\n      </mat-checkbox>\r\n    </button>\r\n    }\r\n\r\n  </mat-menu>\r\n\r\n</div>\r\n\r\n<div #printSection class=\"table-container print-area no-print\"\r\n  [style.--zebra-color]=\"resolvedConfig.appearance.zebraColor\"\r\n  [style.--hover-color]=\"resolvedConfig.appearance.hoverColor || '#e3f2fd'\"\r\n  [style.--selected-row-color]=\"resolvedConfig.appearance.selectedRowColor || '#ffe0b2'\">\r\n\r\n  <table mat-table [dataSource]=\"dataSource\" matSort>\r\n\r\n    @for (col of displayedColumnsExtended; track col.id) {\r\n\r\n    <ng-container [matColumnDef]=\"col.id\">\r\n\r\n      @if (col.type !== 'actions') {\r\n      <th mat-header-cell *matHeaderCellDef [style.width]=\"col.width\" mat-sort-header\r\n        [style.font-size]=\"tableConfig.typography?.heading\" [disabled]=\"!resolvedConfig.sorting.enabled\"\r\n        [arrowPosition]=\"col.align === 'right' ? 'before' : 'after'\" [ngClass]=\"{\r\n          'right-aligned-header': col.align === 'right',\r\n          'center-aligned-header': col.align === 'center',\r\n          'left-aligned-header': !col.align || col.align === 'left'\r\n        }\">\r\n        {{ col.name }}\r\n      </th>\r\n      } @else {\r\n      <th mat-header-cell *matHeaderCellDef [style.width]=\"col.width\"\r\n        [style.font-size]=\"tableConfig.typography?.heading\" [style.text-align]=\"col.align || 'left'\">\r\n        {{ col.name }}\r\n      </th>\r\n      }\r\n\r\n      <td mat-cell *matCellDef=\"let row let i=index\" [attr.data-label]=\"col.name\"\r\n        [style.font-size]=\"tableConfig.typography?.cell\" [ngStyle]=\"row.__cellStyles?.[col.id]\">\r\n\r\n        @if (col.type === 'actions') {\r\n\r\n        @if (isMobileView) {\r\n        <span class=\"cell-label\">{{ col.name }}</span>\r\n        }\r\n\r\n        @if (!(hideActionOnLastRow && i === dataSource.data.length - 1)) {\r\n\r\n        <div class=\"cell-value action-buttons\">\r\n          @if (col.actions?.select?.show && !isActionHide(row, col.actions?.select)) {\r\n          <button mat-icon-button [color]=\"col.actions?.select?.color\"\r\n            [disabled]=\"isActionDisabled(row, col.actions?.select)\" (click)=\"setSelectedRow(row); onSelect(row)\">\r\n            <mat-icon [title]=\"col.actions?.select?.tooltipText ?? 'Select'\">check_circle_outline</mat-icon>\r\n          </button>\r\n          }\r\n\r\n          @if (col.actions?.edit?.show && !isActionHide(row, col.actions?.edit)) {\r\n          <button mat-icon-button [color]=\"col.actions?.edit?.color\"\r\n            [disabled]=\"isActionDisabled(row, col.actions?.edit)\" (click)=\"markRow(row); onEdit(row)\">\r\n            <mat-icon [title]=\"col.actions?.edit?.tooltipText ?? 'Edit'\">edit</mat-icon>\r\n          </button>\r\n          }\r\n\r\n          @if (col.actions?.delete?.show && !isActionHide(row, col.actions?.delete)) {\r\n          <button mat-icon-button [color]=\"col.actions?.delete?.color\"\r\n            [disabled]=\"isActionDisabled(row, col.actions?.delete)\" (click)=\"markRow(row); onDelete(row)\">\r\n            <mat-icon [title]=\"col.actions?.delete?.tooltipText ?? 'Delete'\">delete</mat-icon>\r\n          </button>\r\n          }\r\n          @if (col.actions?.settings?.show && !isActionHide(row, col.actions?.settings)) {\r\n          <button mat-icon-button [color]=\"col.actions?.select?.color\"\r\n            [disabled]=\"isActionDisabled(row, col.actions?.settings)\" (click)=\"markRow(row); onSettings(row)\">\r\n            <mat-icon [title]=\"col.actions?.settings?.tooltipText ?? 'Settings'\">settings</mat-icon>\r\n          </button>\r\n          }\r\n        </div>\r\n        }\r\n\r\n        } @else {\r\n\r\n        @if (isMobileView) {\r\n        <span class=\"cell-label\">{{ col.name }}</span>\r\n        }\r\n\r\n        <span class=\"cell-value\">\r\n\r\n          @switch (col.type) {\r\n\r\n          @case ('integer') {\r\n          {{ row[col.id] | number:'1.0-0' }}\r\n          }\r\n\r\n          @case ('number') {\r\n          <span [innerHTML]=\"highlightSearchedText(row[col.id] | number:(col.digits || '1.2-2'))\"></span>\r\n          }\r\n\r\n          @case ('currency') {\r\n          {{ row[col.id] | currency:'INR' }}\r\n          }\r\n\r\n          @case ('date') {\r\n          {{ row[col.id] | date:'dd-MM-yyyy' }}\r\n          }\r\n\r\n          <!-- @case ('chip') {\r\n          <mat-chip selected [ngStyle]=\"getChipContainerStyle(col)\">\r\n            <span [ngStyle]=\"getChipTextStyle(col)\">\r\n              {{ row[col.id] }}\r\n            </span>\r\n          </mat-chip>\r\n          } -->\r\n\r\n          @case ('chip') {\r\n          <mat-chip [ngStyle]=\"getChipContainerStyle(col, row[col.id])\">\r\n            <span [ngStyle]=\"getChipTextStyle(col, row[col.id])\">\r\n              {{ row[col.id] }}\r\n            </span>\r\n          </mat-chip>\r\n          }\r\n\r\n          @case ('multiline') {\r\n          <ng-container *ngIf=\"row[col.id]?.length; else noData\">\r\n            <div *ngFor=\"let item of row[col.id]\">\r\n              {{ getDisplayValue(item, col) }}\r\n            </div>\r\n          </ng-container>\r\n          <ng-template #noData>-</ng-template>\r\n          }\r\n\r\n          @case ('link') {\r\n          <ng-container *ngIf=\"row[col.id]?.length; else noData\">\r\n            <div *ngFor=\"let item of row[col.id]\" class=\"file-link-row\">\r\n              <a href=\"#\" (click)=\"col['linkClick']\r\n                  ? col['linkClick'](item, $event)\r\n                  : null\">\r\n                {{ getDisplayValue(item, col) }}\r\n              </a>\r\n              <!-- <a [href]=\"getLinkValue(item, col)\" target=\"_blank\" rel=\"noopener noreferrer\">\r\n                {{ getDisplayValue(item, col) }}\r\n              </a> -->\r\n            </div>\r\n          </ng-container>\r\n          <ng-template #noData>-</ng-template>\r\n          }\r\n\r\n          @default {\r\n          <span [innerHTML]=\"highlightSearchedText(row[col.id])\"></span>\r\n          }\r\n\r\n          }\r\n\r\n        </span>\r\n\r\n        }\r\n\r\n      </td>\r\n\r\n      <td mat-footer-cell *matFooterCellDef [ngStyle]=\"getCellStyle(col)\">\r\n        {{ footerValues[col.id] }}\r\n      </td>\r\n\r\n    </ng-container>\r\n\r\n    }\r\n\r\n    <tr mat-header-row *matHeaderRowDef=\"displayedColumnIds; sticky: true\"></tr>\r\n    <!-- <tr mat-row *matRowDef=\"let row; columns: displayedColumnIds\" [class.row-selected]=\"row === selectedRow\"></tr> -->\r\n\r\n    <!-- for Multi Row Select -->\r\n    <tr mat-row *matRowDef=\"let row; columns: displayedColumnIds\" [class.row-selected]=\"isRowSelected(row)\"></tr>\r\n\r\n    @if (resolvedConfig.footer.enabled) {\r\n    <tr mat-footer-row *matFooterRowDef=\"displayedColumnIds; sticky: resolvedConfig.footer.sticky\"></tr>\r\n    }\r\n\r\n  </table>\r\n</div>\r\n\r\n<div class=\"no-print\" *ngIf=\"resolvedConfig.pagination.enabled\">\r\n  <mat-paginator [pageSizeOptions]=\"[5, 10, 25, 100]\" showFirstLastButtons></mat-paginator>\r\n</div>\r\n\r\n<div class=\"print-hint no-print\" *ngIf=\"(displayedColumnIds.length || 0) > 7\">\r\n  For reports with more than 7 columns, select\r\n  <b>Landscape</b> in the print dialog.\r\n</div>", styles: [".table-container{height:500px;overflow:auto;border:1px solid #ddd}.search-field{width:100%}.search-field .mat-mdc-form-field-infix{padding-top:10px;padding-bottom:10px}.mat-mdc-header-row{background:#fff;box-shadow:0 2px 3px #00000014;z-index:10}.mat-mdc-header-row .mat-mdc-header-cell{background:#94baf3;border-bottom:1px solid #dcdcdc;font-weight:600;letter-spacing:3px;font-variant-numeric:tabular-nums}.mat-mdc-header-cell,.mat-mdc-cell,.mat-sort-header-content{font-variant-numeric:tabular-nums}.mat-sort-header-content{letter-spacing:inherit}.table-container .mat-mdc-row:nth-child(2n){background:var(--zebra-color)}.table-container .mat-mdc-row:hover .mat-mdc-cell{background:var(--hover-color)!important}.table-container .mat-mdc-row.row-selected .mat-mdc-cell,.table-container .mat-mdc-row.row-selected:hover .mat-mdc-cell{background:var(--selected-row-color)!important}.table-container .mat-mdc-cell,.table-container .mat-mdc-header-cell{padding-top:0!important;padding-bottom:0!important}.button-container{display:flex;justify-content:space-evenly;align-items:center;padding:20px}.mdc-data-table__cell,.mat-mdc-header-cell{padding:12px 16px}.cell-label{display:none}.cell-value{display:block;width:100%;margin-top:0}.mat-column-flow .cell-value,.mat-column-id .cell-value{padding-right:0}.table-container .mat-column-actions .cell-value{display:flex;align-items:center;justify-content:center}mark{background:#ffeb3b;border-radius:2px;padding:0 2px}button.mat-icon-button{display:flex;flex-direction:column;align-items:center;justify-content:center}.icon-text{font-size:14px;line-height:14px}.toolbaricons{margin:0}.action-buttons{display:flex;align-items:center;justify-content:center;gap:2px}.action-buttons mat-icon{width:24px;height:24px;font-size:24px}.action-buttons .mat-mdc-icon-button{width:28px;height:28px;padding:2px}.print-hint{margin-top:6px;color:#555;font-size:12px}.column-menu{padding:8px 0}.menu-header{padding:8px 16px;border-bottom:1px solid #ddd;font-weight:600}.mat-menu-item{height:auto}@media screen and (max-width: 768px){.mat-mdc-header-row{display:none!important}mat-form-field{width:100%}.mat-mdc-row{display:block!important;margin:16px 0;padding:12px;border:1px solid #e0e0e0;border-radius:8px;background:#fff;height:auto!important;min-height:unset!important}.mat-mdc-cell{display:flex!important;justify-content:flex-start!important;width:100%;padding:8px 0!important;text-align:left!important;border-bottom:1px solid #eee}.mat-mdc-footer-row{display:none!important}.mat-mdc-cell:last-child{border-bottom:none}.mat-mdc-cell:before{content:none}.cell-label{display:block;flex:0 0 40%;font-weight:600;color:#666;text-transform:uppercase}.cell-value{margin-left:auto!important;min-width:0;text-align:right!important;font-variant-numeric:tabular-nums}}@media print{body *,.no-print,.mat-column-actions{display:none!important}.print-area,.print-area *{visibility:visible}.print-area{position:absolute;left:0;top:0;width:100%}.table-container{height:auto!important;overflow:visible!important}}.table-container .mat-mdc-chip{--mdc-chip-container-height: 22px;--mdc-chip-label-text-size: 11px;--mdc-chip-container-shape-radius: 8px}.file-link-row{margin-bottom:.6rem}.file-link-row:last-child{margin-bottom:0}\n"] }]
        }], ctorParameters: () => [{ type: TableExportService }, { type: i0.ChangeDetectorRef }], propDecorators: { columns: [{
                type: Input
            }], tableConfig: [{
                type: Input
            }], data: [{
                type: Input
            }], paginator: [{
                type: ViewChild,
                args: [MatPaginator]
            }], sort: [{
                type: ViewChild,
                args: [MatSort]
            }], printSection: [{
                type: ViewChild,
                args: ['printSection']
            }], rowEdit: [{
                type: Output
            }], rowSelect: [{
                type: Output
            }], rowDelete: [{
                type: Output
            }], rowSettings: [{
                type: Output
            }], hideActionOnLastRow: [{
                type: Input
            }], selectedRows: [{
                type: Input
            }], selectedRowsChange: [{
                type: Output
            }], updateViewMode: [{
                type: HostListener,
                args: ['window:resize']
            }] } });

class ReusableTableModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: ReusableTableModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "18.2.14", ngImport: i0, type: ReusableTableModule, declarations: [ReusableTableComponent], imports: [CommonModule,
            MatTableModule,
            MatPaginatorModule,
            MatSortModule,
            MatIconModule,
            MatButtonModule,
            MatChipsModule,
            MatFormFieldModule,
            MatMenuModule,
            MatCheckboxModule,
            MatTooltipModule,
            MatInputModule], exports: [ReusableTableComponent] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: ReusableTableModule, imports: [CommonModule,
            MatTableModule,
            MatPaginatorModule,
            MatSortModule,
            MatIconModule,
            MatButtonModule,
            MatChipsModule,
            MatFormFieldModule,
            MatMenuModule,
            MatCheckboxModule,
            MatTooltipModule,
            MatInputModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: ReusableTableModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [ReusableTableComponent],
                    imports: [
                        CommonModule,
                        MatTableModule,
                        MatPaginatorModule,
                        MatSortModule,
                        MatIconModule,
                        MatButtonModule,
                        MatChipsModule,
                        MatFormFieldModule,
                        MatMenuModule,
                        MatCheckboxModule,
                        MatTooltipModule,
                        MatInputModule,
                    ],
                    exports: [ReusableTableComponent],
                }]
        }] });

class ReusableTableService {
    constructor() { }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: ReusableTableService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: ReusableTableService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: ReusableTableService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [] });

/*
 * Public API Surface of reusable-table
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ReusableTableComponent, ReusableTableModule, ReusableTableService, TableExportService };
//# sourceMappingURL=reusable-table.mjs.map
